package com.example.qwerty.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.state.LevelRenderState;
import net.minecraft.world.entity.Entity;

import com.example.qwerty.QwertyClient;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {
	@Shadow
	protected abstract EntityRenderState extractEntity(Entity entity, float partialTick);

	// Игра не рисует вашего персонажа, если камера привязана не к нему.
	// Пока включена свободная камера, добавляем игрока в кадр сами.
	@Inject(method = "extractVisibleEntities", at = @At("RETURN"))
	private void qwerty$showPlayer(Camera camera, Frustum frustum, DeltaTracker deltaTracker, LevelRenderState renderState, CallbackInfo ci) {
		if (!QwertyClient.isActive()) {
			return;
		}

		Minecraft client = Minecraft.getInstance();
		Entity player = client.player;
		if (client.level == null || player == null) {
			return;
		}

		float partialTick = deltaTracker.getGameTimeDeltaPartialTick(!client.level.tickRateManager().isEntityFrozen(player));
		renderState.entityRenderStates.add(this.extractEntity(player, partialTick));
	}
}
