package com.example.qwerty;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;

/**
 * qwerty: свободная камера (freecam).
 *
 * Камера отвязывается от игрока и летает сама, а настоящий игрок стоит на месте.
 * Включение: клавиша F6 (меняется в настройках управления) или команда /qwerty.
 * Управление в полёте: W/A/S/D, прыжок вверх, приседание вниз, бег быстрее.
 *
 * Мышь (свайп) крутит камеру, а не игрока: поворот перехватывает EntityMixin.
 * Самого игрока в кадр возвращает LevelRendererMixin.
 */
public class QwertyClient implements ClientModInitializer {
	public static final String MOD_ID = "qwerty";

	/** Обычная скорость камеры, блоков в секунду. */
	private static final double SPEED = 12.0;
	/** Скорость при зажатом беге, блоков в секунду. */
	private static final double SPRINT_SPEED = 40.0;
	/** На сколько блоков позади игрока появляется камера при включении. */
	private static final double START_DISTANCE = 4.0;

	private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
			Identifier.fromNamespaceAndPath(MOD_ID, "main")
	);

	private static boolean active;
	private static CameraEntity cameraEntity;
	private static LocalPlayer savedPlayer;
	private static ClientInput savedInput;

	// Позиция глаз камеры и её углы
	private static double camX;
	private static double camY;
	private static double camZ;
	private static float camYaw;
	private static float camPitch;
	private static long lastNanos;

	private KeyMapping toggleKey;

	@Override
	public void onInitializeClient() {
		toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.qwerty.toggle",
				InputConstants.Type.KEYSYM,
				InputConstants.KEY_F6,
				CATEGORY
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			// Вышли из мира, умерли, сменили измерение: старое состояние недействительно.
			if (active && (client.player == null || client.level == null || client.player != savedPlayer)) {
				resetState();
			}

			while (toggleKey.consumeClick()) {
				toggle(client);
			}
		});

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
				dispatcher.register(ClientCommandManager.literal("qwerty").executes(context -> {
					toggle(Minecraft.getInstance());
					return 1;
				}))
		);

		// Каждый кадр двигаем камеру (применится в следующем кадре).
		WorldRenderEvents.BEFORE_TRANSLUCENT.register(QwertyClient::onFrame);
	}

	// ---------------------------------------------------------------------
	// Вызывается из миксинов
	// ---------------------------------------------------------------------

	/** Включена ли свободная камера. */
	public static boolean isActive() {
		return active;
	}

	/**
	 * Перехватывает поворот мышью. Игра пытается повернуть игрока, мы вместо этого
	 * поворачиваем камеру. Возвращает true, если поворот игрока нужно отменить.
	 */
	public static boolean onTurn(Entity entity, double yawDelta, double pitchDelta) {
		if (!active || cameraEntity == null || entity != Minecraft.getInstance().player) {
			return false;
		}

		// Те же коэффициенты, что у Entity.turn в самой игре.
		camYaw += (float) yawDelta * 0.15f;
		camPitch = Mth.clamp(camPitch + (float) pitchDelta * 0.15f, -90.0f, 90.0f);
		applyRotation();
		return true;
	}

	// ---------------------------------------------------------------------
	// Включение / выключение
	// ---------------------------------------------------------------------

	private static void toggle(Minecraft client) {
		if (active) {
			disable(client);
		} else {
			enable(client);
		}
	}

	private static void enable(Minecraft client) {
		LocalPlayer player = client.player;
		ClientLevel level = client.level;
		if (player == null || level == null) {
			return;
		}

		savedPlayer = player;
		savedInput = player.input;

		// Камера стартует позади игрока и смотрит туда же, куда он: сразу видно персонажа.
		Vec3 eye = player.getEyePosition();
		Vec3 look = player.getLookAngle();
		camX = eye.x - look.x * START_DISTANCE;
		camY = eye.y - look.y * START_DISTANCE;
		camZ = eye.z - look.z * START_DISTANCE;
		camYaw = player.getYRot();
		camPitch = player.getXRot();

		// Невидимая «пустышка», из глаз которой рисуется картинка. В мир она не добавляется.
		cameraEntity = new CameraEntity(level);
		applyRotation();
		syncPosition();

		// Пустой ввод: настоящий игрок перестаёт ходить, прыгать и приседать.
		player.input = new ClientInput();

		client.setCameraEntity(cameraEntity);
		lastNanos = System.nanoTime();
		active = true;

		player.displayClientMessage(Component.translatable("message.qwerty.on"), true);
	}

	private static void disable(Minecraft client) {
		LocalPlayer player = client.player;

		if (player != null) {
			player.input = savedInput;
			client.setCameraEntity(player);
			player.displayClientMessage(Component.translatable("message.qwerty.off"), true);
		}

		resetState();
	}

	private static void resetState() {
		active = false;
		cameraEntity = null;
		savedPlayer = null;
		savedInput = null;
	}

	// ---------------------------------------------------------------------
	// Движение камеры
	// ---------------------------------------------------------------------

	private static void onFrame(WorldRenderContext context) {
		if (!active || cameraEntity == null) {
			return;
		}

		Minecraft client = Minecraft.getInstance();
		LocalPlayer player = client.player;

		if (player == null || client.level == null || player != savedPlayer) {
			resetState();
			return;
		}

		long now = System.nanoTime();
		double dt = Math.min((now - lastNanos) / 1.0e9, 0.1);
		lastNanos = now;

		Options options = client.options;
		double forward = (options.keyUp.isDown() ? 1 : 0) - (options.keyDown.isDown() ? 1 : 0);
		double side = (options.keyLeft.isDown() ? 1 : 0) - (options.keyRight.isDown() ? 1 : 0);
		double vertical = (options.keyJump.isDown() ? 1 : 0) - (options.keyShift.isDown() ? 1 : 0);

		double rad = Math.toRadians(camYaw);
		double sin = Math.sin(rad);
		double cos = Math.cos(rad);

		// Вперёд = (-sin, cos), влево = (cos, sin)
		double moveX = -sin * forward + cos * side;
		double moveZ = cos * forward + sin * side;

		double horizontalLength = Math.sqrt(moveX * moveX + moveZ * moveZ);
		if (horizontalLength > 1.0e-6) {
			moveX /= horizontalLength;
			moveZ /= horizontalLength;
		}

		double speed = options.keySprint.isDown() ? SPRINT_SPEED : SPEED;
		camX += moveX * speed * dt;
		camY += vertical * speed * dt;
		camZ += moveZ * speed * dt;

		syncPosition();
	}

	/** Переносит углы камеры на entity-пустышку без сглаживания между тиками. */
	private static void applyRotation() {
		if (cameraEntity == null) {
			return;
		}

		cameraEntity.setYRot(camYaw);
		cameraEntity.setXRot(camPitch);
		cameraEntity.yRotO = camYaw;
		cameraEntity.xRotO = camPitch;
	}

	/** Переносит позицию камеры на entity-пустышку без сглаживания между тиками. */
	private static void syncPosition() {
		if (cameraEntity == null) {
			return;
		}

		double y = camY - cameraEntity.getEyeHeight();

		cameraEntity.setPos(camX, y, camZ);
		cameraEntity.xo = camX;
		cameraEntity.yo = y;
		cameraEntity.zo = camZ;
	}

	/**
	 * Entity, из которого игра рисует вид. Направление взгляда у живых существ по умолчанию
	 * берётся от головы, а нам нужны обычные углы, поэтому методы переопределены.
	 */
	private static final class CameraEntity extends ArmorStand {
		CameraEntity(Level level) {
			super(EntityType.ARMOR_STAND, level);
		}

		@Override
		public float getViewYRot(float partialTicks) {
			return this.getYRot();
		}

		@Override
		public float getViewXRot(float partialTicks) {
			return this.getXRot();
		}
	}
}
