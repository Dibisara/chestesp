package com.example.qwerty;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;

/**
 * qwerty: свободная камера (freecam).
 *
 * Камера отвязывается от игрока и летает сама, а настоящий игрок стоит на месте.
 * Включение: клавиша F6 (меняется в настройках управления) или команда /qwerty в чате.
 * Управление в полёте: W/A/S/D, пробел вверх, Shift вниз, Ctrl (бег) быстрее.
 */
public class QwertyClient implements ClientModInitializer {
	public static final String MOD_ID = "qwerty";

	/** Обычная скорость камеры, блоков в секунду. */
	private static final double SPEED = 12.0;
	/** Скорость при зажатом беге, блоков в секунду. */
	private static final double SPRINT_SPEED = 40.0;

	private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
			Identifier.fromNamespaceAndPath(MOD_ID, "main")
	);

	private KeyMapping toggleKey;

	private boolean active;
	private ArmorStand cameraEntity;
	private LocalPlayer savedPlayer;
	private ClientInput savedInput;
	private float savedYRot;
	private float savedXRot;

	// Позиция глаз камеры
	private double camX;
	private double camY;
	private double camZ;
	private long lastNanos;

	@Override
	public void onInitializeClient() {
		toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.qwerty.toggle",
				InputConstants.Type.KEYSYM,
				InputConstants.KEY_F6,
				CATEGORY
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (toggleKey.consumeClick()) {
				toggle(client);
			}
		});

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
				dispatcher.register(ClientCommandManager.literal("qwerty").executes(context -> {
					toggle(Minecraft.getInstance());
					return 1;
				}))
		);

		// Каждый кадр двигаем камеру (она применится в следующем кадре).
		WorldRenderEvents.BEFORE_TRANSLUCENT.register(this::onFrame);
	}

	// ---------------------------------------------------------------------
	// Включение / выключение
	// ---------------------------------------------------------------------

	private void toggle(Minecraft client) {
		// Если мир сменился, старое состояние уже недействительно.
		if (active && (client.player == null || client.player != savedPlayer)) {
			resetState();
		}

		if (active) {
			disable(client);
		} else {
			enable(client);
		}
	}

	private void enable(Minecraft client) {
		LocalPlayer player = client.player;
		ClientLevel level = client.level;
		if (player == null || level == null) {
			return;
		}

		savedPlayer = player;
		savedInput = player.input;
		savedYRot = player.getYRot();
		savedXRot = player.getXRot();

		Vec3 eye = player.getEyePosition();
		camX = eye.x;
		camY = eye.y;
		camZ = eye.z;

		// Невидимая «пустышка», из глаз которой рисуется картинка. В мир она не добавляется.
		cameraEntity = new ArmorStand(EntityType.ARMOR_STAND, level);
		syncCameraEntity(player.getYRot(), player.getXRot());

		// Пустой ввод: настоящий игрок перестаёт ходить, прыгать и приседать.
		player.input = new ClientInput();

		client.setCameraEntity(cameraEntity);
		lastNanos = System.nanoTime();
		active = true;

		player.displayClientMessage(Component.translatable("message.qwerty.on"), true);
	}

	private void disable(Minecraft client) {
		LocalPlayer player = client.player;

		if (player != null) {
			player.input = savedInput;
			player.setYRot(savedYRot);
			player.setXRot(savedXRot);
			player.yRotO = savedYRot;
			player.xRotO = savedXRot;
			client.setCameraEntity(player);
			player.displayClientMessage(Component.translatable("message.qwerty.off"), true);
		}

		resetState();
	}

	private void resetState() {
		active = false;
		cameraEntity = null;
		savedPlayer = null;
		savedInput = null;
	}

	// ---------------------------------------------------------------------
	// Движение камеры
	// ---------------------------------------------------------------------

	private void onFrame(WorldRenderContext context) {
		if (!active) {
			return;
		}

		Minecraft client = Minecraft.getInstance();
		LocalPlayer player = client.player;

		// Вышли из мира, умерли, сменили измерение: просто сбрасываем состояние.
		if (player == null || client.level == null || player != savedPlayer) {
			resetState();
			return;
		}

		long now = System.nanoTime();
		double dt = Math.min((now - lastNanos) / 1.0e9, 0.1);
		lastNanos = now;

		// Мышь по-прежнему поворачивает игрока: берём его углы как углы камеры.
		float yaw = player.getYRot();
		float pitch = player.getXRot();

		Options options = client.options;
		double forward = (options.keyUp.isDown() ? 1 : 0) - (options.keyDown.isDown() ? 1 : 0);
		double side = (options.keyLeft.isDown() ? 1 : 0) - (options.keyRight.isDown() ? 1 : 0);
		double vertical = (options.keyJump.isDown() ? 1 : 0) - (options.keyShift.isDown() ? 1 : 0);

		double rad = Math.toRadians(yaw);
		double sin = Math.sin(rad);
		double cos = Math.cos(rad);

		// Вперёд = (-sin, cos), влево = (cos, sin)
		double moveX = -sin * forward + cos * side;
		double moveZ = cos * forward + sin * side;

		double horizontalLength = Math.sqrt(moveX * moveX + moveZ * moveZ);
		if (horizontalLength > 1.0e-6) {
			moveX /= horizontalLength;
			moveZ /= horizontalLength;
		}

		double speed = options.keySprint.isDown() ? SPRINT_SPEED : SPEED;
		camX += moveX * speed * dt;
		camY += vertical * speed * dt;
		camZ += moveZ * speed * dt;

		syncCameraEntity(yaw, pitch);
	}

	/** Переносит позицию и углы камеры на entity-пустышку без сглаживания между тиками. */
	private void syncCameraEntity(float yaw, float pitch) {
		double y = camY - cameraEntity.getEyeHeight();

		cameraEntity.setPos(camX, y, camZ);
		cameraEntity.xo = camX;
		cameraEntity.yo = y;
		cameraEntity.zo = camZ;

		cameraEntity.setYRot(yaw);
		cameraEntity.setXRot(pitch);
		cameraEntity.yRotO = yaw;
		cameraEntity.xRotO = pitch;
	}
}
