package com.example.qwerty.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.world.entity.Entity;

import com.example.qwerty.QwertyClient;

@Mixin(Entity.class)
public class EntityMixin {
	// Пока включена свободная камера, мышь крутит камеру, а не игрока.
	@Inject(method = "turn", at = @At("HEAD"), cancellable = true)
	private void qwerty$onTurn(double yaw, double pitch, CallbackInfo ci) {
		if (QwertyClient.onTurn((Entity) (Object) this, yaw, pitch)) {
			ci.cancel();
		}
	}
}
